---
title: studying
date: 2020-11-16 19:47:19
type: "studying"
​---
---
